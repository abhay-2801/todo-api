package com.example.api.API_demo_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
