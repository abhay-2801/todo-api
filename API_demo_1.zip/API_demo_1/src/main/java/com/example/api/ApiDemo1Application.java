package com.example.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiDemo1Application.class, args);
	}

}
